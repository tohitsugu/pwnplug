module PwnPlug
  class HttpSsh < PwnScript
     def config
       super.merge({
         :port => 3338,
         :config_file => "reverse_ssh_over_HTTP_config.sh",
         :script_file => "reverse_ssh_over_HTTP.sh"
       })
     end

    def make_script(options=@script_values)
      script = "HTTPtunnel_receiver=#{options[:ip]}\n"
      if options[:proxy] == 'on'
        script << "Proxy_enable=YES\n"
        script << "Proxy_address=#{options[:proxy_ip] }\n"
        script << "Proxy_port=#{options[:proxy_port] }\n"
        script << "Proxy_auth_user=#{options[:proxy_auth_user] }\n"
        script << "Proxy_auth_password=#{options[:proxy_auth_password] }\n"
      end
      script
    end
  end
end
