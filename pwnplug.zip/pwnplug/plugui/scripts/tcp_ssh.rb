module PwnPlug
  class TcpSsh < PwnScript
     def config
       super.merge({
         :port => 3333,
         :config_file => "reverse_ssh_config.sh",
         :script_file => "reverse_ssh.sh"
       })
     end

    def make_script(options=@script_values)
      script = "SSH_receiver=#{options[:ip]}\n"
      script << "SSH_receiver_port=#{options[:port]}\n"
      script
    end
  end
end
