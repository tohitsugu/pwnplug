module PwnPlug
  class EvilConfig < PwnScript

    def config
      super.merge({
        :config_file => "evilap_config.sh"
      })
    end


    def make_script(options=@script_values)
      script  = "ssid=\"#{options[:ssid]}\"\n"
    end

  end
end
