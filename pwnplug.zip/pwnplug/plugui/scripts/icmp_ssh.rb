module PwnPlug
  class IcmpSsh < PwnScript

     def config
       super.merge({
         :port => 3339,
         :config_file => "reverse_ssh_over_ICMP_config.sh",
         :script_file => "reverse_ssh_over_ICMP.sh"
       })
     end

    def make_script(options=@script_values)
      script = "SSH_receiver=#{options[:ip]}\n"
      script
    end

  end
end
