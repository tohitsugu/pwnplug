
module PwnPlug
  class DnsSsh < PwnScript
     def config
       super.merge({
         :port => 3335,
         :config_file => "reverse_ssh_over_DNS_config.sh",
         :script_file => "reverse_ssh_over_DNS.sh"
       })
     end
    private

    def make_script(options=@script_values)
      script = "DNStunnel_receiver=#{options[:ip]}\n"
      script
    end
  end
end
