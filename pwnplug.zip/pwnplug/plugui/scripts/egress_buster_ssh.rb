
module PwnPlug
  class EgressBusterSsh < PwnScript

    def config
       super.merge({
         :port => 3334,
         :config_file => "SSH_egress_buster_config.sh",
         :script_file => "SSH_egress_buster.sh"
       })
    end

    def self.pre_select_egress_ssh_port(port)
      filepath = "/var/pwnplug/script_configs/SSH_egress_buster_config.sh"
      # this parses lines that look like "enable21=OFF\n"
      script = File.read(filepath)
      current_val = script.grep(/#{port}/)[0]
      return '' if current_val == nil
      current_val = current_val.strip.split('=')[1]
      if current_val == "YES"
        out = "checked='checked'"
      elsif current_val == "NO"
        out = ''
      else
        out = "something is wrong"
      end
      out
    end

    def make_script(options=@script_values)
      script   = "EgressBuster_receiver=#{options[:ip]}\n"
      script  << "enable21=#{egress_on?(options[:enable21])}\n"
      script  << "enable22=#{egress_on?(options[:enable22])}\n"
      script  << "enable23=#{egress_on?(options[:enable23])}\n"
      script  << "enable25=#{egress_on?(options[:enable25])}\n"
      script  << "enable110=#{egress_on?(options[:enable110])}\n"
      script  << "enable123=#{egress_on?(options[:enable123])}\n"
      script  << "enable161=#{egress_on?(options[:enable161])}\n"
      script  << "enable500=#{egress_on?(options[:enable500])}\n"
      script  << "enable1723=#{egress_on?(options[:enable1723])}\n"
      script  << "enable4500=#{egress_on?(options[:enable4500])}\n"
    end

    def egress_on?(input)
      return 'NO' if input != 'on'
      return 'YES'
    end

  end
end
