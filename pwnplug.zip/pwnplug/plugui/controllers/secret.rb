class PlugUI < Sinatra::Base

  def secret_options
    @title= "Change Plug UI Passsword"
    @setup_current = "current"
  end

  get '/secret/?' do
    secret_options
    erb :secret
  end

  post '/secret/?' do
    secret_options

    if params[:new_secret] != params[:new_secret_confirmation]
      @alert = "Please enter the same password into both fields"
      erb :secret
    elsif params[:new_secret].include?("'") || params[:new_secret].include?('"') || params[:new_secret].include?("!")
      @alert = "Passphrase cannot include ', \" or !"
      erb :secret
    else
      hashed_secret =  Secret.sha512sum(params[:new_secret])
      Secret.write_secret!(hashed_secret)
      redirect '/'
    end

  end

end
