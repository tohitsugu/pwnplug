class PlugUI < Sinatra::Base

  def script_settings
    @title ="Reverse Shells"
    @shell_current = "current"
  end

  get '/script/?' do
    script_settings
    erb :script_form
  end

  ######################
  # This is a substantial part of the original functionality.
  #
  # Basically this one post handles updating the various
  # reverse shell script config files from the posted params.
  #
  # The params have nested hashes keyed by the symbols in the scripts hash below.
  #
  # Each PwnScript inherited class below gets passed into the loop linked to the symbol which ties to it's own form partial.
  #
  # This checks for an :active param and either updates the script settings or clears it out completely.
  post '/script/?' do
    script_settings
    crontab_array = []

    scripts = {
      :tcp_ssh => TcpSsh,
      :http_ssh => HttpSsh,
      :ssl_ssh => SslSsh,
      :dns_ssh => DnsSsh,
      :icmp_ssh => IcmpSsh,
      :gsm_ssh => GsmSsh,
      :egress_buster_ssh => EgressBusterSsh
    }

    scripts.each do |symbol, script_class|
      settings = params[symbol]
      script = script_class.new(settings)
      if settings[:active]
        unless script.check_script
          script.clear_tunnel
          script.write_script
        end
        crontab_string = script.cron_string(settings[:cron])
        crontab_array.push(crontab_string)
      else
        script.blank_out_script
        script.clear_tunnel
      end
    end

    new_commands = crontab_array.join("\n")

    PwnCron.append!(new_commands)

    @alert = "Reverse shell configuration updated."
    erb :script_form
  end

end
