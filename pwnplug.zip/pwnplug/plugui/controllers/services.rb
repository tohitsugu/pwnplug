class PlugUI < Sinatra::Base

  def service_options
    @title = "Plug Services"
    @service_current = "current"
  end

  get '/services/?' do
    service_options
    erb :services
  end

end
