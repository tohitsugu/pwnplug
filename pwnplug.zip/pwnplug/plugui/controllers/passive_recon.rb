class PlugUI < Sinatra::Base

  def passive_recon_settings
    @title = "Passive Recon"
    @service_current = "current"
  end

  get '/passive-recon/?' do
    passive_recon_settings
    erb :passive_recon
  end

  post '/passive-recon/enable/?' do
    passive_recon_settings
    PassiveRecon.enable!
    redirect '/passive-recon'
  end

  post '/passive-recon/disable/?' do
    passive_recon_settings
    PassiveRecon.disable!
    redirect '/passive-recon'
  end

end
