class PlugUI < Sinatra::Base

  def setup_options
    @title = "Basic Setup"
    @setup_current = "current"
  end

  get '/setup/?' do
    setup_options
    erb :setup
  end

  post '/setup/clear/?' do
    setup_options
    System.cleanup!
    @alert = "History and Logs have been cleared"
    erb :setup
  end

end
