class PlugUI < Sinatra::Base

  def sms_alert_settings
    @sms_current ="current"
    @title = "Email/SMS Alerting"
  end

  def text_to_bash_settings
    @sms_current ="current"
    @title = "Text-to-Bash"
  end

  get '/sms-alert/?' do
    sms_alert_settings
    erb :sms
  end

  post '/sms-alert/?' do
    sms_alert_settings
    SmsConfig.new(params).write_script
    SmsConfig.sms_alert
    SmsConfig.send_test_message(params)
    redirect '/sms-alert'
  end

  post '/sms-alert/clear/?' do
    SmsConfig.clear!
    redirect '/sms-alert'
  end

  get '/text-to-bash/?' do
    text_to_bash_settings
    erb :text_to_bash
  end

  post '/text-to-bash/?' do
    gsm_active = PwnCron.check_cron_make_checked("reverse_ssh_over_3G.sh")
    if gsm_active != ""
      @alert = "Text-to-Bash and the SSH-over-3G shell cannot be enabled simultaneously. Please disable the SSH-over-3G shell in the Reverse Shells page before continuing."
      erb :text_to_bash
    else
      TextToBash.enable!(params[:cell_number])
      redirect '/text-to-bash'
    end
  end

  post '/text-to-bash/disable?' do
    TextToBash.disable!
    redirect '/text-to-bash'
  end

end

