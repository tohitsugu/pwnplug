#!/bin/bash
# Script to perform Pwnie Express setup steps on BackTrack 5
# Modified version by Pwnie Express: March-2012
# --------------------------------------------------------------------------
# Copyright (c) 2011 Security Generation <http://www.securitygeneration.com>
# This script is licensed under GNU GPL version 2.0
# --------------------------------------------------------------------------
# This script is part of PwnieScripts shell script collection
# Visit http://www.securitygeneration.com/security/pwniescripts-for-pwnie-express/
# for more information.
# --------------------------------------------------------------------------


pwnplug_user_ssh_key="ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC1LxPYPAE7ljljv1hzBakRoDiLU3fWPO1Ftysm/Lgt/YYUInrJG4+2RUH987DIpps78bWiJjC2MoEMv8EYOgZBzZclG8BBqvN22xSt9SLuBq/cWQEIYHYFUlW7lvjyXUZ/bHq/EtjE5AE5Csy1pcrcfEonM+svFiNoNX0J1SoliaEnAGeMsQHdys+0Gt0/6DCllcm4tGBj4x//mWUPL2/zG+MwFjceO+OgP9+sYKVLjo8rgN3zIwh8DW34NquU1rndsbu2BPvz+x8aHTmHSoX2ZBiCpRKyFI4CzDnzkRiFbe57rMbCBlzXyaE8TrEGnnWHvkhou/7GCXEI16BTlLnR root@pwned"

if [ "$1" == "-h" ]; then
	echo "Configures and starts all Pwn Plug SSH Receiver tunnel listeners."
	exit 0
fi

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# Generate Backtrack SSH server keypair if needed
files=$(ls /etc/ssh/*_key 2> /dev/null | wc -l)
if [ "$files" != "0" ]; then
	echo "[-] SSHd server keys already exist. Skipping generation..."
else
	echo "[+] Generating SSHd server keys..."
	sshd-generate
fi

# Kill any active tunnel connections & listeners
for i in `netstat -lntup |grep pwnplug |awk '{print$7}' |awk -F"/" '{print$1}'`; do kill $i ; done
killall ptunnel
killall stunnel
killall dns2tcpd
killall hts

# Start/restart Backtrack SSH server
echo "[+] Restarting SSHD..."
/etc/init.d/ssh restart

# Create pwnplug user account if needed
cut -d: -f1 /etc/passwd | grep "pwnplug" > /dev/null
OUT=$?
if [ $OUT -eq 0 ];then
	echo "[-] User 'pwnplug' already exists. Skipping."
else
	echo "[+] Adding 'pwnplug' user account..."
	useradd -m pwnplug
fi

# Make pwnplug user .ssh directory if needed
if [ ! -d "/home/pwnplug/.ssh" ]; then
	mkdir /home/pwnplug/.ssh
fi

# Copy pwnplug user SSH public key to authorized_keys
echo "$pwnplug_user_ssh_key" > /home/pwnplug/.ssh/authorized_keys

# Configure & start Reverse-SSH-over-HTTP listener
if [ -e "/usr/bin/hts" ]; then
	echo "[-] HTTPTunnel is already installed."
	echo "[+] Starting Reverse-SSH-over-HTTP (HTTPtunnel) listener..."
	hts -F 0.0.0.0:22 80 &
else
	echo "[+] Installing HTTPtunnel via apt..."
	apt-get --force-yes --yes -qq install httptunnel
	echo "[+] Starting Reverse-SSH-over-HTTP (HTTPtunnel) listener..."
	hts -F 0.0.0.0:22 80 &
fi

# Configure & start Reverse-SSH-over-SSL listener
if [ -d "/root/stunnel/" ]; then	
	echo "[-] stunnel is already configured. Remove directory /root/stunnel/ and re-run this script if you want to reconfigure."
	echo "[+] Starting Reverse-SSH-over-SSL (stunnel) listener..."
	stunnel /root/stunnel/stunnel.conf &
else
	echo "[+] Configuring stunnel..."
	echo "[+] Generating SSL certificate (press enter for all prompts)..."
	#DIR='pwd'
	mkdir /root/stunnel/ && cd /root/stunnel/
	openssl genrsa -out pwn_key.pem 2048
	openssl req -new -key pwn_key.pem -out pwn.csr
	openssl x509 -req -in pwn.csr -out pwn_cert.pem -signkey pwn_key.pem -days 1825
	cat pwn_cert.pem >> pwn_key.pem
	#cd $DIR
	echo "[+] SSL certificate created. Configuring stunnel.conf..."
	echo -e "cert = /root/stunnel/pwn_key.pem\nchroot = /var/tmp/stunnel\npid = /stunnel.pid\nsetuid = root\nsetgid = root\nclient = no\n[22]\naccept = 443\nconnect = 22" >> /root/stunnel/stunnel.conf
	mkdir /var/tmp/stunnel
        echo "[+] Starting Reverse-SSH-over-SSL (stunnel) listener..."
        stunnel /root/stunnel/stunnel.conf &
fi

# Configure & start Reverse-SSH-over-DNS listener
if [ -e /root/dns2tcpdrc ]; then
	echo "[-] DNS2TCP is already configured. Remove /root/dns2tcpdrc and re-run this script if you want to reconfigure."
        echo "[+] Starting Reverse-SSH-over-DNS (dns2tcp) listener..."
        /pentest/backdoors/dns2tcp/dns2tcpd -d 0 -f /root/dns2tcpdrc &
else
	echo "[+] Configuring DNS2TCP..."
	echo -e "listen = 0.0.0.0\nport = 53\nuser = nobody\nchroot = /var/empty/dns2tcp/\ndomain = rssfeeds.com\nresources = ssh:127.0.0.1:22" >> /root/dns2tcpdrc
	mkdir -p /var/empty/dns2tcp/
        echo "[+] Starting Reverse-SSH-over-DNS (dns2tcp) listener..."
        /pentest/backdoors/dns2tcp/dns2tcpd -d 0 -f /root/dns2tcpdrc &
fi

# Start Reverse-SSH-over-ICMP listener
        echo "[+] Starting Reverse-SSH-over-ICMP (ptunnel) listener (Logging to /tmp/ptunnel.log)..."
        /pentest/backdoors/ptunnel/ptunnel -daemon /tmp/ptunnel -f /tmp/ptunnel.log &

echo ""
echo "[+] Setup Complete."
echo "[+] Press ENTER to listen for incoming connections..."
read INPUT
watch -d "netstat -lntup4 | grep 'pwn' | grep 333"

