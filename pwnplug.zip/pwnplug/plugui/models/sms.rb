module PwnPlug
  class Sms

    def self.send_test_message(options={})

     `sendEmail -f "${sms_sender}" -t "${sms_recipient}" -u "${msg_subject}" -m "${msg_body}" -s "${smtp_server}" -o tls="${smtp_tls}" -xu "${smtp_auth_user}" -xp "${smtp_auth_password}"`
   end


  end
end
