module PwnPlug
  class NacBypass
    ENABLE_SCRIPT = '/var/pwnplug/scripts/Enable_NAC_Bypass_mode.sh'

    def self.enable!
      System.run_script(ENABLE_SCRIPT)
    end
  end
end
