module PwnPlug
  class PwnCron
    CRONTAB = "/etc/crontab"

    def self.append!(new_commands)
      new_commands = new_commands + "\n\n"
      System.append_to_file(CRONTAB, new_commands)
    end

    def self.param_to_cron(param)
      if param == "Every Minute"
        "* * * * *"
      elsif param == "Every 5 Minutes"
        "*/5 * * * *"
      elsif param == "Every 15 Minutes"
        "*/15 * * * *"
      elsif param == "Every 60 Minutes"
        "0 * * * *"
      else
        "* * * * *"
      end
    end

    def self.cron_timer_options(name,script)
      out = "<p>\n<select name=\"" +
        name +
        "\">\n<option " +
        PwnCron.selected_cron_timer(script,'*') +
        "\" name=\"Every Minute\">Every Minute</option>\n<option "+
        PwnCron.selected_cron_timer(script,'*/5') +
        "\" name=\"Every 5 Minutes\">Every 5 Minutes</option>\n<option "+
        PwnCron.selected_cron_timer(script,'*/15') +
        "\" name=\"Every 15 Minutes\">Every 15 Minutes</option>\n<option "+
        PwnCron.selected_cron_timer(script,'0') +
        "\" name=\"Every 60 Minutes\">Every 60 Minutes</option>\n</select>\n</p>"
      out
    end

    def self.selected_cron_timer(file, timer)

      timer_for_file = File.read(CRONTAB).grep(/#{file}/)[0]

      timer_for_file == nil ? (timer_string = '' ) : (timer_string = timer_for_file.split(' ')[0])

      if timer == timer_string
        'selected="selected"'
      else
        ''
      end
    end

    def self.check_cron_make_checked(file)
      if File.read(CRONTAB).grep(/#{file}/).size > 0
        'checked="checked"'
      else
        ''
      end
    end

    def self.build_string(timer,command)
      cron = param_to_cron(timer)
      string = cron + " root /var/pwnplug/scripts/" + command
      string
    end
  end
end
