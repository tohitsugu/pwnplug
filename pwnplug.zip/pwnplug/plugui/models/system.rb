module PwnPlug
  class System
    DELIMITER = "### DO NOT EDIT THIS LINE OR BELOW\n"

    def self.run_script(script_path)
      `sh #{script_path}`
    end

    def self.tail(log_file)
      `tail #{log_file}`
    end

    def self.log_tail
      System.tail('/var/log/messages')
    end

    def self.cleanup!
      System.run_script('/var/pwnplug/scripts/cleanup.sh')
    end

    def self.about_kernel
      `uname -a`
    end

    def self.who?
      `w`
    end

    def self.disk_usage
      `df -h`
    end

    def self.reboot!
      `reboot`
    end

    def self.pwn_plug_release
      # `grep Release /etc/motd`
      File.read('/etc/motd').grep(/Release/).first
    end

    #use to $ `ps ax | grep $command` to see if command is running
    def self.is_running(port)
      if System.is_running?(port)
        "Connected to SSH receiver on localhost:" + port + " ."
      else
        "Not Running"
      end
    end

    def self.is_running?(port)
      command = `ps -C ssh -o pid,args |grep -o "#{port}:localhost:22"`
      if command != ""
        true
      else
        false
      end
    end

    def self.append_to_file(system_file,new_string)
      original_system_file = File.read(system_file).split(DELIMITER)[0]
      new_file = [ original_system_file, new_string].join(DELIMITER)

      f = File.open(system_file,'w')
      f.write(new_file)
      f.close
    end
  end
end
