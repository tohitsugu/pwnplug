module PwnPlug
  class Secret
    LOCATION = Dir.pwd + '/.secret'

    def self.current_secret
      File.read(LOCATION).chomp
    end

    def self.write_secret!(new_secret)
      f = File.open(LOCATION, 'w')
      f.write(new_secret)
      f.close
    end

    def self.sha512sum(string)
      `echo "#{ string }" | sha512sum`.chomp
    end

  end
end
