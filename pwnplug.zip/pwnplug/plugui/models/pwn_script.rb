module PwnPlug
  class PwnScript
    ##########################################
    # This is intended as a class which different configuration script helper objects inherit from.
    #
    # Provides a humble way to write and query certain system config files.

    # Constants:
    SCRIPT_PATH = '/var/pwnplug/scripts/'
    CONFIG_PATH = '/var/pwnplug/script_configs/'

    # Class Methods:
    def self.call_value(variable, file)
      script = CONFIG_PATH + file

      unless File.exists?(script)
        f = File.open(script,'w')
        f.write("")
        f.close
      end

      value_line = File.read(script).grep(/#{variable}/)[0]

      if value_line != nil
        output = value_line.split('=')[1]
      else
        output = ''
      end

      # have to remove double quotes...
      # this really only applies to the SMS config
      unless output.nil?
        output.gsub!('"','')
        output.chomp!
      end
      output
    end

    # Instance methods:
    attr_accessor :script_values

    def initialize(script_values = {})
      @script_values = script_values
    end

    def config
      {
        :scripts_directory => '/var/pwnplug/script_configs/',
        :config_file => 'default_config.sh',
        :script_file => 'default.sh',
        :port => '',
      }
    end

    def write_script
  		write_script!(new_script) unless check_script
  	end

    def check_script
      current_script == new_script
    end

    def blank_out_script
      write_script!('')
    end

    def new_script(new_script_values=@script_values)
      make_script(new_script_values)
    end

    def full_path
      CONFIG_PATH + config[:config_file]
    end

    def is_running?
      return false if self.config[:port] == nil
      System.is_running?(self.config[:port])
    end

    def clear_tunnel
      Ssh.close_reverse_shell(config[:port])
    end

    def cron_string(cron_setting)
      PwnCron.build_string(cron_setting, config[:script_file])
    end

    def current_script
      unless File.exists?(full_path)
        write_script!('')
      end

      File.read(full_path)
    end

    def write_script!(script)
  	  f = File.open(full_path,"w")
  	  f.write(script)
  	  f.close
    end

    ######################
    #
    # Methods to be overwritten by inheriting classes
    #
    def make_script(values={})
    	script  = ""
      values.each {|k,v| script << "#{k.to_s}=#{v}\n"}
      script
    end
  end
end
