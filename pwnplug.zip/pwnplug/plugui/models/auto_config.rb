module PwnPlug
  class AutoConfig
    GENERATOR_SCRIPT   = '/var/pwnplug/scripts/Generate_SSH_receiver_autoconfig.sh'
    AUTO_CONFIG_SCRIPT = '/var/pwnplug/scripts/SSH_receiver_autoconfig.sh'

    def self.generate!
      System.run_script(GENERATOR_SCRIPT)
      # copy into public directory for download
      f = File.open(Dir.pwd + '/public/SSH_receiver_autoconfig.sh', 'w+')
      f.write( AutoConfig.body )
      f.close
    end

    def self.body
      unless File.exists?(AUTO_CONFIG_SCRIPT)
        f = File.open(AUTO_CONFIG_SCRIPT, 'w')
        f.write( '' )
        f.close
      end

      File.read(AUTO_CONFIG_SCRIPT)
    end
  end
end
