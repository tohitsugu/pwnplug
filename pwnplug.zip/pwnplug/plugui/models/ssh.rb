module PwnPlug
  class Ssh
    def self.close_reverse_shell(port)
      `kill \`ps -C autossh -o pid,args |grep "autossh -2NR #{ port }" |awk '{print$1}'\``
    end

    def self.public_key
      File.read('/root/.ssh/id_rsa.pub') if File.exists?('/root/.ssh/id_rsa.pub')
    end

    def self.reset!
      `rm -f /root/.ssh/id_rsa /root/.ssh/id_rsa.pub`
      Ssh.generate_keypair
    end

    def self.generate_keypair
      `ssh-keygen -t rsa -f /root/.ssh/id_rsa -P ""`
    end

  end
end
