require 'models/text_to_bash.rb'

include PwnPlug

  until !true

    unless `ps -C smsd | grep -o smsd | tail -n1`.chomp == 'smsd'
      `smsd -m file -c /var/spool/sms/outgoing -f /var/log/smsd.log > /var/spool/sms/incoming/messages &> /dev/null &`
    end

    text_to_bash = TextToBash.new
    text_to_bash.check_for_messages
    sleep 5
  end
