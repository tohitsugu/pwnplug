#!/bin/bash

# Disable IPv6 & Plug UI at next boot
cp /var/pwnplug/scripts/blacklist.conf.nac /etc/modprobe.d/blacklist.conf
update-rc.d -f plugui remove

# Enable NACbypass at next boot
update-rc.d NACbypass defaults

echo "NAC Bypass mode will be enabled at next boot."
