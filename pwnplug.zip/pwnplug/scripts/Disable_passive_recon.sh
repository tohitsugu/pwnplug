#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 3.29.2012

# Variables
recon_dir=/var/log/recon

# Kill any active recon processes
killall ngrep
killall p0f
killall dsniff
killall tcpflow

# Disable Passive Recon at next boot
update-rc.d -f passive_recon remove
