#!/bin/bash

# Enable IPv6 & Plug UI at next boot
cp /var/pwnplug/scripts/blacklist.conf.original /etc/modprobe.d/blacklist.conf
update-rc.d plugui defaults

# Disable NACbypass at next boot
update-rc.d -f NACbypass remove

# Cleanup
route del default gw 0.0.0.0
route del default gw 0.0.0.0
route del default gw 0.0.0.0
ifconfig br0 down
brctl delbr br0
iptables -t nat --flush

echo "NAC Bypass mode will be disabled at next boot."
