#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Get user variables from script_configs
# sms_recipient=
# sms_sender=
# smtp_server=
# smtp_auth_user=
# smtp_auth_password=
# smtp_tls=auto
# msg_subject=
# msg_body=
. /var/pwnplug/script_configs/sms_message_config.sh

# Set variables
tunnel_status=`ps -C ssh -o pid,args |grep -o "2NR 333" |tail -n1`

# If tunnel is up, send SMS message via SMTP
if [ "${tunnel_status}" == "2NR 333" ] ; then \
sendEmail -f "${sms_sender}" -t "${sms_recipient}" -u "${msg_subject}" -m "${msg_body}" -s "${smtp_server}" -o tls="${smtp_tls}" -xu "${smtp_auth_user}" -xp "${smtp_auth_password}" ; \
else echo "Tunnel not established" ; \
fi
