#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 5.1.2012

# Stop Evil AP
killall airbase-ng
killall dhcpd
airmon-ng stop mon0
airmon-ng stop mon1
airmon-ng stop mon3
airmon-ng stop mon4
iptables --flush
iptables --table nat --flush
echo 0 > /proc/sys/net/ipv4/ip_forward
ifdown eth0 && ifup eth0

# Clear SSID variable
rm /var/pwnplug/script_configs/evilap_config.sh

# Disable Evil AP at next boot
update-rc.d -f evilap remove
