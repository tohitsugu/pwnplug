#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Cleanup system logs & SMS spool directories
rm /var/log/apt/*
rm /var/log/kismet/*
rm /var/log/samba/log.*
rm /var/log/stunnel4/*.log
rm /var/log/recon/*.log
find /var/log/ -type f -exec cp /dev/null {} \;
find /var/spool/sms -type f -exec rm {} \;
find /var/log -name "*.gz*" -exec rm {} \;
find /var/log -name "*.[0-9]" -exec rm {} \;

# Cleanup root's history
rm /root/.fishsrv.pl
rm /root/.john/*
rm -rf /root/.msf*/loot/*
rm /root/.msf*/history
rm /root/.msf*/logs/*.log
rm -rf /root/.msf*/logs/sessions/*
find /root -name "*_history" -exec cp /dev/null {} \;

# Clear bash history at every logout
echo "history -c" > /root/.bash_logout

# Remove Plug UI log
rm /var/pwnplug/plugui/webrick.log

# Remove SSH Receiver Autoconfig script
rm -f /var/pwnplug/scripts/SSH_receiver_autoconfig.sh

# Remove Bluetooth device info
rm -rf /var/lib/bluetooth/*
