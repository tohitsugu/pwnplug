#!/bin/bash
# Script to build "SSH_receiver_autoconfig.sh"
# For scripted Backtrack SSH receiver config
# Revised: 3.22.2012

# Variables
pwnplug_user_ssh_key=`cat /root/.ssh/id_rsa.pub`

# Write script header into script

echo "\
#!/bin/bash
# Script to perform Pwnie Express setup steps on BackTrack 5
# Modified version by Pwnie Express: March-2012
# --------------------------------------------------------------------------
# Copyright (c) 2011 Security Generation <http://www.securitygeneration.com>
# This script is licensed under GNU GPL version 2.0
# --------------------------------------------------------------------------
# This script is part of PwnieScripts shell script collection
# Visit http://www.securitygeneration.com/security/pwniescripts-for-pwnie-express/
# for more information.
# --------------------------------------------------------------------------

" > /var/pwnplug/scripts/SSH_receiver_autoconfig.sh

# Write pwnplug user SSH key variable to script

echo pwnplug_user_ssh_key=\""$pwnplug_user_ssh_key"\" >> /var/pwnplug/scripts/SSH_receiver_autoconfig.sh
echo "" >> /var/pwnplug/scripts/SSH_receiver_autoconfig.sh 

# Write modified script body into script

cat /var/pwnplug/scripts/SSH_receiver_autoconfig_script_body >> /var/pwnplug/scripts/SSH_receiver_autoconfig.sh

chmod +x /var/pwnplug/scripts/SSH_receiver_autoconfig.sh
