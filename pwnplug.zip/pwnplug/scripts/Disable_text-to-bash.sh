#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 5.3.2012

# Kill any running instances of pppd/smsd/etc
killall pppd
killall smsd
kill `ps -C ruby -o pid,args |grep "send_sms_response.rb" |awk '{print$1}'`
sleep 3
killall -9 smsd
kill -9 `ps -C ruby -o pid,args |grep "send_sms_response.rb" |awk '{print$1}'`

# Clear authorized number
cp /dev/null /var/pwnplug/plugui/.authorized_number

# Disable text-to-bash at next boot
update-rc.d -f text-to-bash remove

echo ""
echo "Text-to-bash disabled."
