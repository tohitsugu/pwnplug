#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.5.2012


# Disable IPv6
cp /var/pwnplug/scripts/blacklist.conf.nac /etc/modprobe.d/blacklist.conf

# Disable ICMP ping replies
cp /var/pwnplug/scripts/sysctl.stealth /etc/sysctl.conf

# Disable Plug UI
update-rc.d -f plugui remove

# Set local SSH server to listen on loopback address only
cp /var/pwnplug/scripts/sshd_config.stealth /etc/ssh/sshd_config

echo "Stealth mode will be enabled at next boot."
