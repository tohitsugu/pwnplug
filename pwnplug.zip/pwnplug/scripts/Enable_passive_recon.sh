#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012

# Variables
recon_dir=/var/log/recon
listening_interface=eth0

# Kill any active recon processes and clear logs
killall ngrep
killall p0f
killall dsniff
killall tcpflow
rm -f "$recon_dir"/*.log
sleep 1

# Start fresh recon processes and log to recon_dir
tcpflow -i "$listening_interface" -c -s port 80 | egrep ": GET |: POST |^Host: |^User-Agent: |^Referer: |^Cookie: " > "$recon_dir"/http.log &
p0f -qtl -i "$listening_interface" > "$recon_dir"/p0f.log &
dsniff -i "$listening_interface" > "$recon_dir"/dsniff.log &

# Enable Passive Recon at next boot
update-rc.d passive_recon defaults
