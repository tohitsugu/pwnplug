#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.2.2012

echo "!WARNING! This script will remove all files in the root user's home directory and all reverse shell configs!"
echo "Press ENTER to continue, CTRL+C to abort."
read INPUT

# Remove MSF source files
rm -rf /opt/metasploit/msf3/external

# Strip debug symbols
strip -s /usr/bin/*
strip -s /usr/sbin/*

# Remove docs/manuals
apt-get -y --force-yes --purge remove man
rm -r /usr/share/doc/*
rm -r /usr/share/man/*
rm -r /usr/share/man8/*

# Cleanup apt
apt-get -y --force-yes autoremove --purge
apt-get -y --force-yes clean
apt-get -y --force-yes autoclean

# Purge orphaned packages, archives, & config files
apt-get -y --force-yes install deborphan
apt-get remove --purge $(deborphan)
apt-get remove --purge $(deborphan)
apt-get remove --purge $(deborphan)
apt-get remove --purge $(deborphan)
rm /var/cache/apt/archives/*.deb
rm /var/cache/apt/pkgcache.bin /var/cache/apt/srcpkgcache.bin
dpkg --list |grep "^rc" |cut -d " " -f 3 |xargs dpkg --purge
rm -rf /tmp/*

# Clear out root user's home directory
cd /root
ls /root |xargs rm -rf
rm -rf /root/.ssh/*

# Clear out reverse shell config files
rm /var/pwnplug/script_configs/*

# Run standard history cleanup script
/var/pwnplug/scripts/cleanup.sh
