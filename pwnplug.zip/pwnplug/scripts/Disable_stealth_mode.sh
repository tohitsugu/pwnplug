#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.26.2012


# Enable IPv6
cp /var/pwnplug/scripts/blacklist.conf.original /etc/modprobe.d/blacklist.conf

# Enable ICMP ping replies
cp /var/pwnplug/scripts/sysctl.original /etc/sysctl.conf

# Enable Plug UI
update-rc.d plugui defaults

# Set local SSH server to listen on 0.0.0.0
cp /var/pwnplug/scripts/sshd_config.original /etc/ssh/sshd_config

echo "Stealth mode will be disabled at next boot."
