#!/bin/bash
# Copyright 2010-2015 Rapid Focus Security, LLC
# pwnieexpress.com
#
# This script contains proprietary software distributed under the terms of the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Use of this software signifies your agreement to the Rapid Focus Security, LLC End User License Agreement (EULA).
#
# Rapid Focus Security, LLC EULA: http://pwnieexpress.com/pdfs/RFSEULA.pdf
#
# Revision: 4.30.2012

echo "--------------------------------------------------------"
echo "Kill any running instances of pppd/smsd/etc"
echo "--------------------------------------------------------"
killall pppd
killall smsd
kill `ps -C ruby -o pid,args |grep "send_sms_response.rb" |awk '{print$1}'`
sleep 3
killall -9 smsd
kill -9 `ps -C ruby -o pid,args |grep "send_sms_response.rb" |awk '{print$1}'`

#echo "Start smsd, write incoming messages to /var/spool/sms/incoming/messages, look for outgoing messages in /var/spool/sms/outgoing"
#smsd -m file -c /var/spool/sms/outgoing -f /var/log/smsd.log > /var/spool/sms/incoming/messages &> /dev/null &

echo "--------------------------------------------------------"
echo "Start the ruby SMS message handler"
echo "--------------------------------------------------------"
cd /var/pwnplug/plugui
ruby send_sms_response.rb &

echo "--------------------------------------------------------"
echo "Enable text-to-bash at next boot"
echo "--------------------------------------------------------"
update-rc.d text-to-bash defaults

echo ""
echo "--------------------------------------------------------"
echo "Text-to-bash enabled."
echo "--------------------------------------------------------"
